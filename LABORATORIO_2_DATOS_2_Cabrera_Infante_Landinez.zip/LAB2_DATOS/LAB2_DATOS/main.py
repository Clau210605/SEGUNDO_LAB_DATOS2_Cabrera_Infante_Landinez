import customtkinter as ctk
from frame_principal import FramePrincipal
from funciones import grafo
from PIL import Image

# Se crea el grafo de aeropuertos
grafo_aeropuertos = grafo

# Defines aquí la clase FrameInicial, que es lo primero que se muestra en la aplicación
class FrameInicial(ctk.CTkFrame):
    def __init__(self, master):
        super().__init__(master)
        self.configure(bg_color="#3E868C", fg_color="transparent")        
        #Configuración de la ventana        
        self.rowconfigure(0, weight=1)
        self.columnconfigure(0, weight=1)
        self.img_logo = ctk.CTkImage(light_image=Image.open("./LAB2_DATOS/img/logo.png"), size=(200,200))
        self.placer = ctk.CTkLabel(self, image=self.img_logo, bg_color="#3E868C", font=("Arial", 20), width=600, height = 200, corner_radius=0, fg_color="transparent", text="")
        self.placer.place(x=350, y=200)
        #bg(fondo)
        self.titulo = ctk.CTkLabel(self, text="AeroGestor", bg_color="#3E868C", font=("Arial", 40), width=600, height = 74, corner_radius=0, fg_color="transparent")
        self.titulo.place(x=350, y=450)
        
        self.boton_empezar = ctk.CTkButton(self, text="Empezar", fg_color="#FED995", hover_color="#FED005" , bg_color="#3E868C",width=200, height = 34, corner_radius=10, command=lambda: self.master.select_frame_by_name("main"), text_color="black")
        self.boton_empezar.place(x=550, y=550)
    

class App(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.geometry("1300x700")
        self.resizable(False, False)
        
        #Configuración de la ventana        
        self.title("Título")
        self.rowconfigure(0, weight=1)
        self.columnconfigure(0, weight=1)
        
        #Frames Inicial y Main
        self.frame_inicial = FrameInicial(self)
        self.frame_inicial.grid(row=0, column=0, sticky="nsew")
        # Agregar el grafo en lugar de None
        self.frame_main = FramePrincipal(self, grafo_aeropuertos)
    
    #Función para cambiar de frame
    def select_frame_by_name(self, frame_name):
        
        if frame_name == "inicial":
            self.frame_inicial.grid(row=0, column=0, sticky="nsew")
        elif frame_name == "main":
            self.frame_main.grid(row=0, column=0, sticky="nsew")
        else: 
            self.frame_inicial.grid_forget()
            

app = App()
app.mainloop()