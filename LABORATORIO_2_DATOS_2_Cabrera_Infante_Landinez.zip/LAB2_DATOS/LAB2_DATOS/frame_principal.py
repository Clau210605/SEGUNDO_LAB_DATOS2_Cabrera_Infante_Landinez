import customtkinter as ctk
from tkintermapview import TkinterMapView
from PIL import Image
from funciones import mostrar_camino_minimo_mod, search


class FramePrincipal(ctk.CTkFrame):
    def __init__(self, master, grafo_aeropuertos):
        super().__init__(master)
        #Se coloca el grid
        self.grid_rowconfigure(0, weight=1)
        self.grid_columnconfigure(1, weight=4)
        self.grafo = grafo_aeropuertos
        self.configure(bg_color="#1B263B", fg_color="transparent")
        
        # Se crea el menú
        self.menu_frame = ctk.CTkFrame(self, corner_radius=0, bg_color="#1B263B", width=200, height=800, fg_color="transparent")
        self.menu_frame.grid(row=0, column=0, sticky="nsew", padx=0, pady=0)
        self.menu_frame.grid_rowconfigure(10, weight=1)
        self.menu_frame.grid_columnconfigure(2, weight=1)
        self.img_logo = ctk.CTkImage(light_image=Image.open("./LAB2_DATOS/img/logo.png"), size=(200,200))
        
        #Elementos del menú
        #Botones Menú
        self.logo_button = ctk.CTkButton(self.menu_frame, text="", fg_color="transparent", bg_color="#1B263B",width=200, height = 74, corner_radius=0, image=self.img_logo)
        self.logo_button.grid(row=0, column=0, sticky="nsew", padx=5, pady=5, columnspan=3)
        self.home_button = ctk.CTkButton(self.menu_frame, text="Información", fg_color="transparent", bg_color="#1B263B",width=200, height = 74, corner_radius=0, font=("Arial", 20), command=lambda: self.select_frame_by_name("home"))
        self.home_button.grid(row=1, column=0, sticky="nsew", padx=0, pady=0, columnspan=3)
        self.page2_button = ctk.CTkButton(self.menu_frame, text="Información y mapa", fg_color="transparent", bg_color="#1B263B",width=200, height = 74, corner_radius=0, font=("Arial", 20),  command=lambda: self.select_frame_by_name("frame_2"))
        self.page2_button.grid(row=2, column=0, sticky="nsew", padx=0, pady=0, columnspan=3)
        
        
        #Crea el Frame 1
        self.home_frame = ctk.CTkFrame(self, corner_radius=0, fg_color="transparent", bg_color="#3E868C")
        self.home_frame.grid(row=0, column=1, sticky="nsew") 
        self.home_frame.grid_rowconfigure(5, weight=1)
        self.home_frame.grid_columnconfigure(5, weight=1)   
        
        self.label = ctk.CTkLabel(self.home_frame, text="AeroGestor", bg_color="#3E868C", font=("Arial", 30), width=600, height = 74, corner_radius=0)
        self.label.grid(row=0, column=2, padx=50, pady=10, sticky="nsew", columnspan=4)
        self.label2 = ctk.CTkLabel(self.home_frame, text="Código del aeropuerto: ", bg_color="#3E868C", font=("Arial", 18), width=600, height = 74, corner_radius=0)
        self.label2.grid(row=1, column=2, padx=50, pady=20, sticky="nsew", columnspan=4)
        self.textbox0 = ctk.CTkTextbox(master=self.home_frame, width=100, corner_radius=10, height=20, bg_color="#3E868C", fg_color="#1B263B")
        self.textbox0.place(x=500, y=100)
        self.botn1 = ctk.CTkButton(self.home_frame, text="Buscar", fg_color="#FED995", hover_color="#FED005" , bg_color="#3E868C",width=200, height = 34, corner_radius=10, command=lambda: self.info(), text_color="black")
        self.botn1.place(x=450, y=200)
        self.textarea = ctk.CTkTextbox(master=self.home_frame, width=400, corner_radius=10, height=300, bg_color="#3E868C", fg_color="#1B263B")
        self.textarea.place(x=60, y=300)
        self.textareanuevo = ctk.CTkTextbox(master=self.home_frame, width=400, corner_radius=10, height=300, bg_color="#3E868C", fg_color="#1B263B")
        self.textareanuevo.place(x=600, y=300)
        
      
        
        
        #Crea el frame 2
        self.frame2 = ctk.CTkFrame(self, corner_radius=0, fg_color="transparent", bg_color="#3E868C")
        
        
        #Label 
        self.label_frame2 = ctk.CTkLabel(self.frame2, text="Información y Mapa", bg_color="#3E868C", font=("Arial", 30), width=600, height = 74, corner_radius=0)
        self.label_frame2.place(x=200, y=10)
        self.label_codigo1 = ctk.CTkLabel(self.frame2, text="Código del aeropuerto 1: ", bg_color="#3E868C", font=("Arial", 18), width=600, height = 74, corner_radius=0)
        self.label_codigo1.place(x=100, y=70) 
        self.label_codigo2 = ctk.CTkLabel(self.frame2, text="Código del aeropuerto 2: ", bg_color="#3E868C", font=("Arial", 18), width=600, height = 74, corner_radius=0)
        self.label_codigo2.place(x=100, y=120)
        
        #Textbox
        self.textbox1 = ctk.CTkTextbox(master=self.frame2, width=100, corner_radius=10, height=20, bg_color="#3E868C", fg_color="#1B263B")
        self.textbox1.place(x=500, y=100)
        self.textbox2 = ctk.CTkTextbox(master=self.frame2, width=100, corner_radius=10, height=20, bg_color="#3E868C", fg_color="#1B263B")
        self.textbox2.place(x=500, y=150)
        
        self.buton_mapa = ctk.CTkButton(self.frame2, text="Mostrar en Mapa", fg_color="#FED995", hover_color="#FED005" , bg_color="#3E868C",width=200, height = 34, corner_radius=10, command=lambda: self.mapa(), text_color="black")
        self.buton_mapa.place(x=450, y=200)
        
        
        #Map
        self.map_widget = TkinterMapView(self.frame2, width= 1000, height= 500)
        self.map_widget.place(x=150, y=300)
        self.map_widget.set_tile_server("https://mt0.google.com/vt/lyrs=m&x={x}&y={y}&z={z}&s=Ga", max_zoom= 25)
        
        
        
    def info(self):
        # Limpiar el textbox
        self.textarea.delete(0.0, "end")
        self.textareanuevo.delete(0.0, "end")
        # Obtener el texto de los textbox
        codigo = self.textbox0.get(0.0 , "end")
        codigo = codigo.replace("\n", "")
        print(codigo)
        # Buscar el aeropuerto
        output1 = search(codigo)
        self.textarea.insert(0.0, output1)
        
        # Buscar los 10 aeropuertos más lejanos
        output2 = self.grafo.cm_Dijkstra(codigo)
        # Mostrar la información
        self.textareanuevo.insert(0.0, output2)
        
    def mapa(self):
        # Obtener el texto de los textbox
        codigo1 = self.textbox1.get(0.0 , "end")
        codigo2 = self.textbox2.get(0.0 , "end")
        # Quitar el salto de línea
        codigo1 = codigo1.replace("\n", "")
        codigo2 = codigo2.replace("\n", "")
        mostrar_camino_minimo_mod(self.grafo, codigo1, codigo2, self.map_widget)
        print(codigo1)
        print(codigo2)
        
    
    def select_frame_by_name(self, name):
        # seleccionar frame
        self.home_button.configure(fg_color=("#1B263B") if name == "home" else "transparent")

        # show selected frame
        if name == "home":
            self.home_frame.grid(row=0, column=1, sticky="nsew")
        else:
            self.home_frame.grid_forget()
            
        if name == "frame_2":
            self.frame2.grid(row=0, column=1, sticky="nsew")   
        else:
            self.frame2.grid_forget()
            
    
    def funcion1(self, valor1, valor2):
        resultado = valor1 + valor2