import pandas as pd
# import folium
import numpy as np
import math
import tkintermapview as tkmap

df = pd.read_csv("LAB2_DATOS/flights_final.csv") #asignación de archivo a variable
global info #se define como variable global
info = df.values.tolist() #se convierte cada columna de la base de datos en una lista

distancia = [] #lista para guardar las distancias entre los aeropuertos
for i in range(len(info)): #ciclo con rango igual al tamaño de la lista "info"
  latitud_s = np.radians(info[i][4]) #latitud de aeropuerto de salida
  longitud_s = np.radians(info[i][5]) #longitud de aeropuerto de salida
  latitud_d = np.radians(info[i][10]) #latitud de aeropuerto de llegada
  longitud_d = np.radians(info[i][11]) #longitud de aeropuerto de llegada

  longitud = longitud_d - longitud_s #diferencia entre ambas longitudes
  latitud = latitud_d- latitud_s #diferencia entre ambas latitudes

  #aplicación de la fórmula de harversine
  a = np.sin(latitud/2)**2 + np.cos(latitud_s) * np.cos(latitud_d) * np.sin(longitud/2)**2
  c = 2 * np.arcsin(np.sqrt(a))
  radio = 6371 #radio estandar de la Tierra
  dist = c * radio
  distancia.append([info[i][0], info[i][6], dist]) #se guarda nombre de ambos aeropuertos y respectiva distancia entre ellos

for i in range(6):
  print(distancia[i])

# Crear lista con códigos de aeropuertos sin repetir
sin_rep = pd.concat([df['Source Airport Code'], df['Destination Airport Code']], ignore_index=True)
sin_rep = sin_rep.unique().tolist()
print(sin_rep)
  
class grafoPonderado:
  inf = math.inf
  def __init__ (self, n: int, directed: bool = False) -> None:
    self.n = n #número de vértices
    self.directed = directed #grafo no dirigido porque es False
    self.Costos = [[self.inf if i != j else 0 for i in range(n)] for j in range(n)] #se crea matriz de costos

  def arista(self, v_inicial: int, v_final: int, peso: float = float('inf')) -> bool: #método para crear aristas
    if v_inicial is not None and v_final is not None:
        if not (0 <= v_inicial < self.n) or not (0 <= v_final < self.n):
            return False
        #grafo no dirigido por tanto se guarda misma distancia en ambas direcciones
        self.Costos[v_inicial][v_final] = peso
        if not self.directed:
            self.Costos[v_final][v_inicial] = peso
        return True

  def distancia_minima(self, distancias, visitado):
  #método para encontrar vértice con distancia mínima aún no visitado
    min_dist = float('inf') #se inicializa distancia minima con infinito
    min_vert = None
    for v in range(self.n): #se recorre cada vértice del grafo
      if float(distancias[v]) < float(min_dist) and not visitado[v]:
      #si el valor que está en la lista dist (lista de distancias)
      #es menor que distancia minima actual
      #y el vértice no ha sido visitado

        min_dist = distancias[v] #actualiza distancia minima
        min_vert = v #actualiza índice de vértice con distancia min
    return min_vert

  #dijkstra para 10 caminos minimos mayores
  def cm_Dijkstra(self, vertice):
    vertice = sin_rep.index(vertice)  # Obtener el índice del vértice en 'sin_rep'
    distancias = [float('inf')] * self.n
    distancias[vertice] = 0
    visitado = [False] * self.n
    maximos_cm = []  # Conjunto para rastrear los 10 caminos mínimos mayores
    aeropuertos_agregados = set()  # Conjunto para rastrear aeropuertos ya agregados

    while not all(visitado):
        actual = self.distancia_minima(distancias, visitado)
        if actual is None:
            break
        visitado[actual] = True
        for v in range(self.n):
            # Permite explorar todas las conexiones, incluso si el costo es cero
            if not visitado[v]:
                new_dist = distancias[actual] + self.Costos[actual][v]
                if new_dist < distancias[v]:
                    distancias[v] = new_dist
                    aeropuerto = sin_rep[v]  # Obtener el nombre del aeropuerto
                    if aeropuerto not in aeropuertos_agregados:
                        maximos_cm.append((new_dist, v))
                        maximos_cm.sort(reverse=True)  # Ordenar la lista por distancia
                        maximos_cm = maximos_cm[:10]  # Mantener solo los 10 más largos
                        aeropuertos_agregados.add(aeropuerto)

    informacion = " Los 10 caminos minimos mayores son: \n"
    for dist, vertice in maximos_cm:
        aeropuerto = sin_rep[vertice]
        informacion += f"\nAeropuerto: {aeropuerto}, Distancia: {dist} km\n"

    
    informacion += " \n La información de los aeropuertos es: \n"
    for i in range(10):
      informacion += search(sin_rep[maximos_cm[i][1]]) + "\n"
    return informacion



grafo = grafoPonderado(len(sin_rep), False) #la cantidad de vértices es igual al tamaño de la lista que
                                            #se creó con los nombres de todos los aeropuertos sin repetir
                                            #y se manda el booleano False para indicar que es un grafo no dirigido.
for dist in distancia:
  grafo.arista(sin_rep.index(dist[0]),sin_rep.index(dist[1]),dist[2])


  # Distancia mínima desde nodos no visitados
def obtener_distancia_minima(distancias, visitados):
  distancia_minima = float('inf')
  nodo_minimo = None
  for nodo, distancia in enumerate(distancias):
    if distancia < distancia_minima and nodo not in visitados:
      distancia_minima = distancia
      nodo_minimo = nodo
  return nodo_minimo

# Aplicar el algoritmo de Dijkstra
def dijkstra(matriz_adyacencia, nodo_inicial, nodo_final):
  numero_nodos = len(matriz_adyacencia)
  distancias = [float('inf')] * numero_nodos
  predecesores = [None] * numero_nodos
  visitados = set()  # Track visited nodes
  distancias[nodo_inicial] = 0
  while len(visitados) < numero_nodos:
    nodo_actual = obtener_distancia_minima(distancias, visitados)
    if nodo_actual is None:
      break
    visitados.add(nodo_actual)
    for vecino, peso in enumerate(matriz_adyacencia[nodo_actual]):
      if peso > 0:
        nueva_distancia = distancias[nodo_actual] + peso
        if nueva_distancia < distancias[vecino]:
          distancias[vecino] = nueva_distancia
          predecesores[vecino] = nodo_actual
  camino = []
  nodo_actual = nodo_final
  while nodo_actual is not None:
    camino.insert(0, nodo_actual)
    nodo_actual = predecesores[nodo_actual]
  return distancias[nodo_final],camino

def search(cod): # Buscar info según código
  for i in range(len(info)):
    if info[i][0]==cod:
      print('Código del aeropuerto: ',info[i][0])
      print('\nNombre del aeropuerto: ',info[i][1])
      print('\nCiudad donde se ubica el aeropuerto: ',info[i][2])
      print('\nPaís donde se ubica el aeropuerto: ',info[i][3])
      print('\nLatitud del aeropuerto: ',info[i][4])
      print('\nLongitud del aeropuerto: ',info[i][5])
      return f"\nCódigo: {info[i][0]}\nNombre: {info[i][1]}\nCiudad: {info[i][2]}\nPaís: {info[i][3]}\nLatitud: {info[i][4]}\nLongitud: {info[i][5]}"
  
  return f"\n  Dicho codigo no esta en la base de datos. \n "

def search2(cod): # Buscar info según código
  for i in range(len(info)):
    if info[i][0]==cod:
      return [info[i][0],info[i][1],info[i][2],info[i][3],info[i][4],info[i][5]]
   
  return f"\n  Dicho codigo no esta en la base de datos. \n "  

def mostrar_camino_minimo_mod(grafo, codigo_origen, codigo_destino, mapa):
    #Limpiar mapa
    mapa.delete_all_marker()
    mapa.delete_all_path()
    # Obtener los índices de los vértices en el grafo a partir de sus códigos
    indice_origen = sin_rep.index(codigo_origen)
    indice_destino = sin_rep.index(codigo_destino)

    # Encontrar el camino mínimo utilizando el algoritmo de Dijkstra
    distancias, camino = dijkstra(grafo.Costos, indice_origen, indice_destino)
    # Agregar marcadores para cada aeropuerto en el camino
    punto_anterior = None
   
    nodo1 = sin_rep[camino[0]]
    print(nodo1)
    x = search2(nodo1)
    print(x)
    x = x[4:6]
    # x es una lista con latitud y longitud
    
    for codigo in camino:
      x = search2(sin_rep[codigo])
      x = x[4:6]
      # x es una lista con latitud y longitud
      latitud = x[0]
      longitud = x[1]
      mapa.set_marker(latitud, longitud, text = search(sin_rep[codigo]))
      mapa.set_position(latitud, longitud)
      mapa.set_zoom(5)
      if punto_anterior is not None:
        mapa.set_path([punto_anterior, (latitud, longitud)])
      punto_anterior = (latitud, longitud)
      

        
